%Create simulated data for snapshot scan algorithms.
%Generates several random datasets with the given parameters.
%All datasets generated are stored in a single excel file, which can be
%passed to batch_time_sim.
%INPUTS:
%n - number of data points for each dataset snapshot
%p - number of covariates for each dataset
%tau - Center of shifted distribution in target area in snapshot 2
%num - Size of target area is snapshot 2
%dist - Which error distribution to use.  Values should be in {1,2,3}
%       1: Normal error
%       2: Exponential error
%       3: Uniform error
%reps - How many random datasets to generate
%dir - directory where datafile should be written
function n = generateData(n,p,tau,num,dist,reps,dir)
    M = [];
    for i=1:reps
        beta = 10*rand(p+1,1)-5;
        [X1,Y1,L1,X2,Y2,L2,T2] = paraSimTime(n,p,beta,dist,num,tau);
        
        M = [M,L1,X1,Y1,L2,X2,Y2,T2];
    end
    ds = ["Norm","Exp","Unif"];
    name = strcat(int2str(n),"x",int2str(p),"_sz",int2str(num),"_tau",int2str(tau*100),"_",ds(dist),".csv");
    csvwrite(strcat(dir,name),M);
end
