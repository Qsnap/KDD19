%Calculate gumbel parameters for TESS
function [u,s] = GumbelGenScan(reps,X1,Y1,L1,X2,Y2,L2,tau,ms)
    V = zeros(reps,1);
    %Pool data
    X = [X1;X2];
    Y = [Y1;Y2];
    L = [L1;L2];
    for i=1:reps
        %Randomize data split
        I = ones(size(Y));
        I(randsample(length(I),length(Y1))) = 2;
        x1 = X(I==1,:);
        x2 = X(I==2,:);
        y1 = Y(I==1);
        y2 = Y(I==2);
        l1 = L(I==1,:);
        l2 = L(I==2,:);
        
        %Run general scan
        [max_t,~,~] = TESS(x1,y1,l1,x2,y2,l2,tau,100,100,ms);
        
        %accumulate max value
        V(i) = max_t;
    end
    %Calculate Gumbel distribution
    xb = sum(V)/reps;
    st = std(V);
    s = st*sqrt(6)/pi;
    u = xb - .5772*s;
end