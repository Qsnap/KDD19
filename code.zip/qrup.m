%QR update algorithm when adding a rank one matrix uv'.
%INPUTS:
%Q - Previous Q matrix, n x p
%R - Previous R matrix, p x p
%u - n x 1
%v - p x 1, transpose of row vector in rank one addition
%OUPUTS:
%New values of Q and R
function [Q,R] = qrup(Q,R,u,v)
    orth_u = ortho_basis(u,Q);
    Q = [Q,orth_u];
    R = [R;zeros(1,size(R,2))];
    w = Q'*u;
    %Compute givens rotations to cancel out w
    for i=(length(w)-1):-1:1
        [c,s] = givens(w(i),w(i+1));
        %G = planerot([w(i),w(i+1)]');
        Q(:,[i,i+1]) = Q(:,[i,i+1])*[c,s;-s,c] ;
        R([i,i+1],:) = [c,-s;s,c] * R([i,i+1],:);%G* R([i,i+1],:);%
        w([i,i+1]) = [c,-s;s,c] * w([i,i+1]);%G* w([i,i+1]);%
    end

    R(1,:) = R(1,:)+w(1)*v';
    %Make R upper triangular (only 1-off diagonal values need to be zeroed)
    for i=1:(size(R,1)-1)
        [c,s] = givens(R(i,i),R(i+1,i));
        %G = planerot([R(i,i),R(i+1,i)]');
        R([i,i+1],i:end) = [c,-s;s,c] * R([i,i+1],i:end);%G* R([i,i+1],i:end);%
        Q(:,[i,i+1]) = Q(:,[i,i+1])*[c,s;-s,c];
    end
    Q = Q(:,1:(end-1));
    R = R(1:(end-1),:);

end

%Compute givens rotation values
function [c,s] = givens(a,b)
    if b==0
        c=1;
        s=0;
    else
        if abs(b) > abs(a)
            t = -a/b;
            s = 1/sqrt(1+t^2);
            c = s*t;
        else
            t = -b/a;
            c = 1/sqrt(1+t^2);
            s = c*t;
        end
    end
end

function [c,s] = givensFast(a,b)
    c=1;
    s=0;
    if b==0
        return
    end
    v = min(abs(a),abs(b))/ max(abs(a),abs(b));
    s = 1/sqrt(1+v^2);
    c = -sign(a/b)*v*s;
    if abs(a) > abs(b)
        t = s;
        s = c;
        c = t;
    end
end

function u=ortho_basis(u,Q)
    %p = (u'*Q*Q')';  %**n^2p Not good, change to (u'*Q)*Q', np+np
    p = Q'*u;
    p = Q*p;
    %for i=1:size(Q,2)
    %    p = p + (Q(:,i)'*u)*Q(:,i);
    %end
    u = u - p;
    u = u / sqrt(u'*u);
end