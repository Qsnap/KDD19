%Special migration search used for eBird data.
%Divides data into multipe snapshots, and looks for uniqiue regions between
%consecutive snapshots.
%Intermediate results are stored in "migrate_results/".
%Qsnap, TESS, and SSS-Moods are all run concurrently, to save time.
%INPUTS:
%tau - the value of tau to use for each algorithm.
%sz - the size of each snapshot window, in number of days.
function n = ebird_migrate(tau,sz)
    start = 1;
    file = "eBird_Western_Corridor_2017.csv";
    F = csvread(file,1);
    Y = F(:,2);
    L = F(:,4:5);
    D = F(:,7);
    X = [ones(size(F,1),1),F(:,8)];
    
    %Assume data is pre-sorted by day of year
    %Parse out data by weeks, run algorithms on time slices
    for i=1:length(D)
        if D(i) > sz*(start-1)
            p_id_1 = i;
            break;
        end
    end
    for i=p_id_1:length(D)
        if D(i) > sz*start
            p_id_2 = i-1;
            break;
        end
    end
    
    id = p_id_2+1;
    
    for w = (start+1):ceil(D(length(D))/sz)
        w;
        %Find stopping point of next data segment
        for i=id:length(D)
            if D(i) > sz*w
                id = i;
                break;
            end
        end
        if id > (length(D)-100)
            id = length(D)+1;
        end
        
        %Parse out data snapshots
        X1 = X(p_id_1:p_id_2,:);
        X2 = X((p_id_2+1):(id-1),:);
        L1 = L(p_id_1:p_id_2,:);
        L2 = L((p_id_2+1):(id-1),:);
        Y1 = Y(p_id_1:p_id_2);
        Y2 = Y((p_id_2+1):(id-1));
        
        %Run algorithms on snapshots
        snapshot_scan(X1,X2,Y1,Y2,L1,L2,tau,w,sz);
        %Store results
        
        %Set previous snapshot to current
        p_id_1 = p_id_2+1;
        p_id_2 = id-1;
    end
end

function [best_t,best_areas] = snapshot_scan(X1,X2,Y1,Y2,L1,L2,tau,w,sz)
    min_size = 20;
    max_size = 10000;
    X = [X1;X2];
    Y = [Y1;Y2];
    L = [L1;L2];
    I = [ones(length(Y1),1);2*ones(length(Y2),1)];
    S = 1:length(Y);
    lon_max = max(L(:,2))-min(L(:,2));
    lat_max = ( max(L(:,2))-min(L(:,2)) )/2;
    
    best_t = zeros(3);
    best_areas = zeros(3,5);
    
    [beta,hid] = qrsimplex(X,Y,tau);
    
    [t_beta,~,~,~,stats] = regress(Y1,X1);
    var = stats(4);
    Pv = pvals(X2,Y2,t_beta,var);
    Pv = [zeros(size(Y1));Pv];
    
    %Divide data into starting points (bottom left corners)
    c_num = 25;
    max_d = max(L,[],1);
    min_d = min(L,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    
    works = 0;
    for i=1:size(C,1)
        start = C(i,:);
        bound = start + [lat_max,lon_max];
        %determine points inside maximum rectangle
        ids = ((L(:,1) > start(1)) & (L(:,1) < bound(1))) & ((L(:,2) > start(2)) & (L(:,2) < bound(2)));
        ids = S(ids);
        if length(ids)==0
            continue;
        end
        %Determine point order for expanding rectangle
        dist = max(L(ids,:)-start,[],2);
        [sv,ord] = sort(dist);
        ord = ids(ord);
        if length(ord) > max_size
            ord = ord(1:max_size);
        end
        
        if max(I(ord))==1 || min(I(ord)) == 2
            continue;
        end
        
        %Ensure algorithms start with min value of points in each snapshot
        num1=0;
        num2=0;
        val = 0;
        while(num1 < min_size || num2 < min_size)
            val = val+1;
            if val > length(ord)
                break;
            end
            if(I(ord(val)) == 1)
                num1 = num1+1;
            else
                num2 = num2+1;
            end
        end
        if val > length(ord)
            continue;
        end
        ids = [I(ord),ord'];
        works = works+1;
        %Run algorithms on data sequence
        [t,best_id] = test_regions(ids,val,X,Y,tau,Pv);
        %Construct bounding boxes for regions
        for a=1:length(t)
            if t(a) > best_t(a)
                best_t(a) = t(a);
                CL = L(ids(1:best_id(a),2),:);
                box = [min(CL,[],1),max(CL,[],1)];
                best_areas(a,:) = [box,t(a)];
            end
        end
        
    end
    if works > 0
        [w,works,length(Y)]
    end
    %Save intermediate results
    sfile = strcat("migrate_results/w_",int2str(w),"_tau_",int2str(tau*100),"_sz_",int2str(sz));
    save(sfile,'best_areas');
end

function [best_t,best_id] = test_regions(ids,min_size,X,Y,tau,Pv)
    %Algorithm indices: 1-Tess, 2-SSS_Moods, 3-QSnap
    best_t = zeros(3,1);
    best_id = zeros(3,1);
    p = size(X,2);
    
    %Make initial dataset and initialize variables
    %TESS
    range = -.19:.01:.09;
    alphas = tau+range;
    %initialize for minimum size region
    Na = alphas*0;
    N=0;
    for i=1:(min_size-1)
        if ids(i,1) == 2
            N = N+1;
            Na = Na + (Pv(ids(i,2)) < alphas);
        end
    end

    %QSNAP
    %Initiatize null Qh and Rh
    [Qh,Rh] = qr(X(ids(p:-1:1,2),:));
    %Initialize null Qz and Rz
    X2 = X(ids(p:-1:1,2),:);
    X2(ids(p:-1:1,1) == 1,:) = zeros(sum(ids(p:-1:1,1)==1),p);
    Z = X2-Qh*(Qh'*X2);
    [Qz,Rz] = qr(Z);
    

    %Update QRh and QRz through min_size
    for i=(p+1):(min_size-1)
        x = X(ids(i,2),:);
        v = x;
        if ids(i,1) == 1
            v = zeros(size(x));
        end
        [Qh,Rh,u] = qrRow(Qh,Rh,x);
        [Qz,Rz] = qrRow(Qz,Rz,x*0);
        X2 = [v;X2];
        g = u'*X2;
        [Qz,Rz] = qrup(Qz,Rz,u,g');
    end
    %fit initial beta and b
    Xc = X(ids((min_size-1):-1:1,2),:);
    Yc = Y(ids((min_size-1):-1:1,2));
    [beta,hid] = qrsimplex(Xc,Yc,tau);
    
    %Moods
    X1 = X(ids(1:(min_size-1),2),:);
    X1 = X1(ids(1:(min_size-1),1)==1,:);
    Y1 = Y(ids(1:(min_size-1),2));
    Y1 = Y1(ids(1:(min_size-1),1)==1);
    [beta_m,hid_m] = qrsimplex(X1,Y1,tau);
    
    %Incrementally grow region, update test values
    for i=min_size:size(ids,1)
        %TESS
        if ids(i,1) == 2 %Only care about points in X2
            N = N+1;
            Na = Na + (Pv(ids(i,2)) < alphas);
            a = Na/N;
            den = 2*alphas.*(1-alphas);
            T = N*(a-alphas).^2./(den);
        
            T = max(T);
        
            if T > best_t(1)
                best_t(1) = T;
                best_id(1) = i;
            end
        end
        
        
        %QSNAP
        %Update QRh and QRz
        x = X(ids(i,2),:);
        v = x;
        if ids(i,1) == 1
            v = zeros(size(x));
        end
        [Qh,Rh,u] = qrRow(Qh,Rh,x);
        [Qz,Rz] = qrRow(Qz,Rz,v*0);
        X2 = [v;X2];
        g = u'*X2;
        [Qz,Rz] = qrup(Qz,Rz,u,g');
        
        %Update beta and rank vector
        Xc = X(ids(i:-1:1,2),:);
        Yc = Y(ids(i:-1:1,2));
        
        [beta,hid,d] = qrsimplex(Xc,Yc,tau,beta,hid+1);

        %Faster rank value update
        b = zeros(size(Yc));
        b(Yc - Xc*beta > 0) = 1;
        b(hid) = d+(1-tau);
        
        %Calculate T
        U = b'*Qz;
        T = U*U';
        T = T/(tau*(1-tau));
        
        if T > best_t(3)
            best_t(3) = T;
            best_id(3) = i;
        end
        
        %Moods
        if ids(i,1) == 1
            X1 = [X1;X(ids(i,2),:)];
            Y1 = [Y1;Y(ids(i,2))];
            [beta_m,hid_m] = qrsimplex(X1,Y1,tau,beta_m,hid_m);
        end
        T = zeros(2,2);
        D = Y(ids(1:i,2)) - X(ids(1:i,2),:)*beta;
        D = round(sign(D)/2+1.5);
        for j=1:length(D)
            T(ids(j,1),D(j)) = T(ids(j,1),D(j))+1;
        end
        %calculate test value
        [~,~,t] = chi2cont(T);
        if t > best_t(2)
            best_t(2) = t;
            best_id(2) = i;
        end
    end
end



function p = pvals(X2,Y2,beta,var)
    std = sqrt(var);
    p = Y2*0;
    for i=1:length(Y2)
        mu = X2(i,:)*beta;
        p(i) = normcdf(Y2(i),mu,std);
    end
end