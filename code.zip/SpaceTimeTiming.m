%Code to compare inner loop exectuion time for different implemenations of
%Qsnap.
%Compares the naive implementation, warmstarted implementation, and fully
%optimized versions.
%INPUTS:
%n - Number of points in each snapshot
%p - Number of covariates in each snapshot
%OUTPUTS:
%times - vector of average update times for the inner loop of each algorithm.  
%           Order is: naive, warmstart, fully optimized
function times = SpaceTimeTiming(n,p)
    min_size = 100;
    max_size = n;
    tau = .75;
    %Make random X and Y 
    X = 20*rand(n,p+1)-10;
    X(:,1) = 1;
    Y = 100*rand(n,1);
    
    %Make ids, alternate time slices
    ids = ones(max_size,2);
    ids(:,2) = 1:max_size;
    ids(mod(ids(:,2),2)==0,1) = 2;
    
    %Time update for all 3 methods, going over entire dataset
    times = zeros(1,3);
    
    tic;
    [best_t,best_id] = SlowLoop(X,Y,ids,tau,min_size);
    times(1) = toc;
    
    tic;
    [best_t,best_id] = WarmLoop(X,Y,ids,tau,min_size);
    times(2) = toc;
    
    tic;
    [best_t,best_id] = FastLoop(X,Y,ids,tau,min_size);
    times(3) = toc;

    times = times./max_size;
end

function [best_t,best_id] = SlowLoop(X,Y,ids,tau,min_size)
    best_t = 0;
    best_id = 0;
    p = size(X,2);

    %Initialize X2
    X2 = X(ids((min_size-1):-1:1,2),:);
    X2(ids((min_size-1):-1:1,1) == 1,:) = zeros(sum(ids((min_size-1):-1:1,1)==1),p);

    
    %calculate T
    for i=min_size:size(ids,1)
        X1 = X(ids(i:-1:1,2),:);
        Y1 = Y(ids(i:-1:1,2));
        
        x = X(ids(i,2),:);
        v = x;
        if ids(i,1) == 1
            v = zeros(size(x));
        end
        
        %Update X2 and H
        X2 = [v;X2];
        H = X1*((X1'*X1)\X1');
        Z = X2-H*X2;
        
        [beta,hid,d] = qrsimplex(X1,Y1,tau);

        %Faster rank value update
        b = zeros(size(Y1));
        b(Y1 - X1*beta > 0) = 1;
        b(hid) = d+(1-tau);
        
        %Calculate T
        T = b'*Z*((Z'*Z)\Z'*b);
        T = T/(tau*(1-tau));
        if T > best_t
            best_t = T;
            best_id = i;
        end
    end
end

function [best_t,best_id] = WarmLoop(X,Y,ids,tau,min_size)
    best_t = 0;
    best_id = 0;
    p = size(X,2);

    %Initialize X2
    X2 = X(ids((min_size-1):-1:1,2),:);
    X2(ids((min_size-1):-1:1,1) == 1,:) = zeros(sum(ids((min_size-1):-1:1,1)==1),p);

    %fit initial beta and b
    X1 = X(ids((min_size-1):-1:1,2),:);
    Y1 = Y(ids((min_size-1):-1:1,2));
    [beta,hid] = qrsimplex(X1,Y1,tau);
    
    %calculate T
    for i=min_size:size(ids,1)
        X1 = X(ids(i:-1:1,2),:);
        Y1 = Y(ids(i:-1:1,2));
        
        x = X(ids(i,2),:);
        v = x;
        if ids(i,1) == 1
            v = zeros(size(x));
        end
        
        %Update X2 and H
        X2 = [v;X2];
        H = X1*((X1'*X1)\X1');
        Z = X2-H*X2;
        
        [beta,hid,d] = qrsimplex(X1,Y1,tau,beta,hid+1);

        %Faster rank value update
        b = zeros(size(Y1));
        b(Y1 - X1*beta > 0) = 1;
        b(hid) = d+(1-tau);
        
        %Calculate T
        T = b'*Z*((Z'*Z)\Z'*b);
        T = T/(tau*(1-tau));
        if T > best_t
            best_t = T;
            best_id = i;
        end
    end
end

function [best_t,best_id] = FastLoop(X,Y,ids,tau,min_size)
    best_t = 0;
    best_id = 0;
    p = size(X,2);

    %Initiatize null Qh and Rh
    [Qh,Rh] = qr(X(ids(p:-1:1,2),:));
    %Initialize null Qz and Rz
    X2 = X(ids(p:-1:1,2),:);
    X2(ids(p:-1:1,1) == 1,:) = zeros(sum(ids(p:-1:1,1)==1),p);
    Z = X2-Qh*(Qh'*X2);
    [Qz,Rz] = qr(Z);

    %Update QRh and QRz through min_size
    for i=(p+1):(min_size-1)
        x = X(ids(i,2),:);
        v = x;
        if ids(i,1) == 1
            v = zeros(size(x));
        end
        [Qh,Rh,u] = qrRow(Qh,Rh,x);
        [Qz,Rz] = qrRow(Qz,Rz,x*0);
        X2 = [v;X2];
        g = u'*X2;
        [Qz,Rz] = qrup(Qz,Rz,u,g');
    end
    %fit initial beta and b
    Xc = X(ids((min_size-1):-1:1,2),:);
    Yc = Y(ids((min_size-1):-1:1,2));
    [beta,hid] = qrsimplex(Xc,Yc,tau);
    
    %Incrementally calculate T
    for i=min_size:size(ids,1)
        %Update QRh and QRz
        x = X(ids(i,2),:);
        v = x;
        if ids(i,1) == 1
            v = zeros(size(x));
        end
        [Qh,Rh,u] = qrRow(Qh,Rh,x);
        [Qz,Rz] = qrRow(Qz,Rz,v*0);
        X2 = [v;X2];
        g = u'*X2;
        [Qz,Rz] = qrup(Qz,Rz,u,g');
        
        %Update beta and rank vector
        Xc = X(ids(i:-1:1,2),:);
        Yc = Y(ids(i:-1:1,2));
        
        [beta,hid,d] = qrsimplex(Xc,Yc,tau,beta,hid+1);

        %Faster rank value update
        b = zeros(size(Yc));
        b(Yc - Xc*beta > 0) = 1;
        b(hid) = d+(1-tau);
        
        %Calculate T
        U = b'*Qz;
        T = U*U';
        T = T/(tau*(1-tau));
        if T > best_t
            best_t = T;
            best_id = i;
        end
    end
end


