%Simplex method for solving quantile regression
%INPUTS:
%X - Covariate matrix
%Y - Response vector
%tau - quantile to fit, [0,1]
%beta - Optional for warmstarting: parameter vector of previous solution
%H - Optional for warmstarting: Indicies of points on the solution plane
%OUTPUTS:
%beta - parameter vector for quantile
%H - Indicies of points on the solution plane
%psi - Derivative values at solution.  Used to calculate dual solution.
function [beta,H,psi] = qrsimplex(X,Y,tau,beta,H)
    iter = 100;
    eps = .00001;
    n = size(X,1);
    p = size(X,2);
    
    
    if nargin < 4
        %Get a full rank subset of Xc to start regression on.
        r = 1;
        hid = 1;
        A = X(1,:);
        for i=2:size(X,1)
            if rank([A;X(i,:)]) > r
                A = [A;X(i,:)];
                r = rank(A);
                hid = [hid;i];
            end
            if r == size(X,2)
                break;
            end
        end
        beta = X(hid,:)\Y(hid);
        if length(hid) < size(X,2)
            v = size(X,2) - length(hid);
            %ids = setdiff(1:size(X,1),hid);
            hid = [hid;hid(1:v)];
        end
        
        H = hid;
    end
    
    IX = inv(X(H,:));
    R = Y - X*beta;
    for it = 1:iter
        %Calculate derivative
        prod = X*IX;
        D = -tau*sum(prod,1) + sum(prod(R < -eps,:),1)+tau*sum(prod(H,:),1);
        psi = D;
        D = [D+1-tau,-D+tau];
        [d,id] = min(D);
        if d > 0
            break;
        end
        if id > p
            id = id-p;
            delta = -IX(:,id);
        else
            delta = IX(:,id);
        end
        
        alpha=0;
        %Do a simplex step
        dx = X*delta;
        dr = R./dx;
        [vr,ord] = sort(dr,'descend');
        sum2 = -(tau-.5)*sum(dx)+.5*sum(abs(dx));
        sum1 = 0;
        for i=1:n
            sum1 = sum1+abs(dx(ord(i)));
            if (sum1-sum2) > -eps
                alpha = vr(i);
                nid = ord(i);
                break;
            end
        end
        
        if abs(alpha)<eps
            break;
        end
        
        %Update inverse with sherman-morrison formula
        v = X(nid,:)-X(H(id),:);
        Au = IX(:,id);
        vA = v*IX;
        IX = IX - (Au*vA)/(1+v*Au);
        
        %Update residuals, beta, and H
        R = R - alpha*dx;
        beta = beta+alpha*delta;
        H(id) = nid; 
        
        
        
    end
end