%Creates partial AUC plots from simulation results
%INPUTS:
%dir - directory where results file is located
%n - number of data points in each snapshot
%ps - a vector of p values to include
%sz - The size of the target region in snapshot 2
%tau - a vector of tau values to include
%       These should be in the range [0,100], as they appear in the file
%       names.
%dist - The error distribution.  One of "Norm", "Exp", or "Unif"
%gt - Graph title
%OUTPUTS:
%Sa - Matrix indicating which results are significant.
%     Each column corresponds to an algorithm: TESS, Qsnap, then SSS-Moods
%     Each row corresponds to an experiment, iterating over p, then tau
%           (This is the same order as the graph shows)
%     If a value is 1, then the algorithm for that column is significantly
%     better for the test at that row.
function Sa = PlotAUCResults(dir,n,ps,sz,tau,dist,gt)
    algs = 1:3;
    max_fpr = .2;
    %Load data
    for p = 1:length(ps)
        for t=1:length(tau)
            sfile = strcat(dir,int2str(n),"x",int2str(ps(p)),"_sz",int2str(sz),"_tau",int2str(tau(t)),dist);
            V = load(sfile);
            V = V.M;
            FA(:,:,:,t,p) = V; 
        end
    end
    
    
    Ya = [];
    Ba = [];
    Sa = [];
    for t=1:length(tau)
        for d=1:length(ps)
            D = FA(:,:,:,t,d);
            AUC = zeros(size(D,1),length(algs));
            av_auc = zeros(1,length(algs));
            B = av_auc;
            SA = B;
            
            %Calculate partial AUC on each dataset for each algorithm.
            for a = algs
                for i = 1:size(D,1)
                    tpr = D(i,2,a)/D(i,4,a);
                    fpr = D(i,3,a)/D(i,5,a);
                    if fpr < max_fpr
                        AUC(i,a) = tpr * (max_fpr-fpr);
                    end
                end
                %Calculate average partial AUC over all datasets
                av_auc(a) = sum(AUC(:,a))/size(AUC,1);
            end
            [~,id] = max(av_auc);
            p=0;
            SA = zeros(1,length(algs));
            %Keep track of best algorithm in order to bold later
            B(id) = av_auc(id);
            av_auc(id) = 0;
            
            %Determine if best algorithm is significantly better than
            %others
            for j=1:length(algs)
                if j ~= id
                    p1 = signrank(AUC(:,j),AUC(:,id));
                    p = max(p,p1);
                end
            end
            if p <= .05
                SA(id) = 1;
            end
            %Store values for plots
            Ya = [Ya;av_auc];
            Sa = [Sa;SA];
            Ba = [Ba;B];
        end
    end
    
    leg = ["TESS","QSnap","SSS-Moods"];
    tlabs = [{'3','5','10'}];
    ord = [3,1,2];
    tlabs = repmat(tlabs,1,length(tau));

    C = [0.8500,0.3250,0.0980;0.9290,0.6940,0.1250;0,0.4470,0.7410];
    %Plot values
    clf
    hold on
    
    b1 = bar(Ya(:,ord)); 
    b2 = bar(Ba(:,ord),'LineWidth',3); %Give best values bold outline
    
    
    for i = 1:size(C,1)
        b2(i).FaceColor = C(i,:);
        b1(i).FaceColor = C(i,:);
    end
    
    xticks(1:length(tau)*3);
    xticklabels(tlabs);
    
    hold off
    ylim([0,.1]);
    %axis([0,.1,0,1])
    legend('',leg(ord), 'Location', 'NorthWest')
    xlabel("P")
    ylabel("Partial AUC")
    title(gt)
end