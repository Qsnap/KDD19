%Snapshot scan implementation of TESS
%INPUTS:
%X1 - Covariates from snapshot 1
%Y1 - Responses from snapshot 1
%L1 - Locations from snapshot 1
%X2, Y2, L2 - Covariates, responses, and locations from snapshot 2
%tau - quantile to compare, [0,1]
%Gu, Gs - Parameters for gumbel distribution for p-value correction
%ms - Maximum region size
function [max_t, loc, SA] = TESS(X1,Y1,L1,X2,Y2,L2,tau,Gu,Gs,ms)
    alpha = .05;
    min_size = 20;
    max_size = min(ms,length(Y2));
    SA = zeros(0,size(L2,2)+2);
    loc = zeros(1,size(L2,2)+1);

    %1 Fit regression model to dataset 1
    [beta,~,~,~,stats] = regress(Y1,X1);
    var = stats(4);
    
    %2 Calculate p-values for dataset 2
    Pv = pvals(X2,Y2,beta,var);
    
    
    %3 Perform expanding circle scans on p-values, keeping track of
    %significant regions.
    
    %setup start locations
    c_num = 10;
    max_d = max(L2,[],1);
    min_d = min(L2,[],1);
    C = zeros(c_num^length(max_d),length(max_d));
    for i=1:c_num
        range = ((i-1)*c_num+1):(i*c_num);
        C(range,:) = [(1:c_num)',ones(c_num,1)*i];
    end
    C = C .* (max_d-min_d)/c_num;
    C = C + min_d;
    
    %Do spatial search for different start points
    max_t = 0;
    for i=1:size(C,1)
        start = C(i,:);
        D = sqrt(sum((L2-start).^2,2));
        [d,ids] = sort(D);

        ids = ids(1:max_size,:);
        [t,id] = GenLoop(Pv,ids,tau,min_size);
        if t>max_t
            max_t = t;
            radius = max(D(ids(1:id)));
            loc = [start,radius];
        end
        p = evcdf(-t,-Gu,Gs);
        if p < alpha
            radius = max(D(ids(1:id)));
            hs = [start,radius,p];
            SA = [SA;hs];
            
        end
    end
    %c_ids = c_ids - length(Y1);
    [d,id] = sort(SA(:,end));
    SA = SA(id,:);
    
end

function [max_t,id] = GenLoop(Pv,ids,alpha,min_size)
    max_t = 0;
    range = -.19:.01:.09;
    alphas = alpha+range;
    %initialize for minimum size region
    N = min_size;
    Na = alphas*0;
    for i=1:min_size
        Na = Na + (Pv(ids(i)) < alphas);
    end
    
    %Calculate incremental test statistic
    for i=(min_size+1):length(ids)
        N = N+1;
        Na = Na + (Pv(ids(i)) < alphas);
        a = Na/N;
        den = 2*alphas.*(1-alphas);
        T = N*(a-alphas).^2./(den);
        
        T = max(T);
        
        if T > max_t
            max_t = T;
            id = i;
        end
    end
end


function p = pvals(X2,Y2,beta,var)
    std = sqrt(var);
    p = Y2*0;
    for i=1:length(Y2)
        mu = X2(i,:)*beta;
        p(i) = normcdf(Y2(i),mu,std);
    end
end