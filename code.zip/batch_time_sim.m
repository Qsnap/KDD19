%Run batches of simulation experiments
%Datasets are read from directory i_dir
%Results are written in directory o_dir
%Runs Qsnap, TESS, and SSS-Moods by default
%Inputs are used to determine which simulation file to read, specify
%parameters of the data.
%INPUTS:
%n - Number of points per snapshot in dataset
%p - Number of covariates in snapshot
%num - Size of target area in snapshot 2
%tau - Where distribution is shifted in target area.  Also specifies tau
%for each algorithm.
%dist - The error distribution of the dataset.  Either "Norm", "Exp", or
%"Unif".
function [t] = batch_time_sim(n,p,num,tau,dist)
    i_dir = "Simulation_Data_Paper/";
    o_dir = "Simulation_Results_Paper/";
    ms = 1500;
    algs = 3;
    t = zeros(1,algs);
    
    
    %Calculate Gumbel distribution
    gr = 200;
    gs = min(ms,n)-20;%size(X,1) - 4*size(X,2);
    gn = 10^2;
    [Gu,Gs] = Gumbel(gr,gs,gn,p);
    [MGu,MGs] = Gumbel(gr,gs,gn,2);

    %Read in all datasets
    f_name = strcat(int2str(n),"x",int2str(p),"_sz",int2str(num),"_tau",int2str(tau*100),"_",dist,".csv");
    AD = csvread(strcat(i_dir,f_name));
    reps = size(AD,2)/(7+2*(p+1));
    
    M = zeros(reps,5,algs);
    %Run algorithms on each dataset
    for r=1:reps
        r
        
        of = (r-1)*(9+2*p);
        L1 = AD(:,(1:2)+of);
        X1 = AD(:,(3:(3+p))+of);
        Y1 = AD(:,3+p+of+1);
        L2 = AD(:,((5+p):(6+p))+of);
        X2 = AD(:,((7+p):(7+2*p))+of);
        Y2 = AD(:,(8+2*p)+of);
        T2 = AD(:,(9+2*p)+of);
        
        I = 1:length(Y2);
        
        [Ggu,Ggs] = GumbelGenScan(200,X1,Y1,L1,X2,Y2,L2,tau,ms);
        
        ttp = sum(T2);
        tfp = n - sum(T2);
        
        aid = 3;
        tic
        [max_t,loc,SAm] = MoodsTime(X1,Y1,L1,X2,Y2,L2,tau,MGu,MGs,ms);
        t(aid) = t(aid)+toc;
        center = loc(1:(end-1));
        radius = loc(end);
        D = sqrt(sum((L2-center).^2,2));
        c_ids = I(D < radius);
        
        %Compile statistics
        g = evcdf(-max_t,-MGu,MGs);
        tp = sum(T2(c_ids));
        fp = sum(T2(c_ids)==0);
        M(r,:,aid) = [g,tp,fp,ttp,tfp];
        
        
        aid = 2;
        tic
        [max_t,loc,SAr] = RankTestTime(X1,Y1,L1,X2,Y2,L2,tau,Gu,Gs,ms);
        t(aid) = t(aid)+toc;
        center = loc(1:(end-1));
        radius = loc(end);
        D = sqrt(sum((L2-center).^2,2));
        c_ids = I(D < radius);
        
        %Compile statistics
        g = evcdf(-max_t,-Gu,Gs);
        tp = sum(T2(c_ids));
        fp = sum(T2(c_ids)==0);
        M(r,:,aid) = [g,tp,fp,ttp,tfp];
        
        aid = 1;
        tic
        [max_t,loc,SAt] = TESS(X1,Y1,L1,X2,Y2,L2,tau,Ggu,Ggs,ms);
        t(aid) = t(aid)+toc;
        center = loc(1:(end-1));
        radius = loc(end);
        D = sqrt(sum((L2-center).^2,2));
        c_ids = I(D < radius);
        
        %Compile statistics
        g = evcdf(-max_t,-Ggu,Ggs);
        tp = sum(T2(c_ids));
        fp = sum(T2(c_ids)==0);
        M(r,:,aid) = [g,tp,fp,ttp,tfp];
    end
    t = t/reps;
    
    sfile = strcat(o_dir,int2str(n),"x",int2str(p),"_sz",int2str(num),"_tau",int2str(tau*100),dist);
    save(sfile,'M');
end